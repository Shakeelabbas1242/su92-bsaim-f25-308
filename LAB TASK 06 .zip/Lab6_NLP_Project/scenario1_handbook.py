from task2_chunks import DOCS
print("Scenario 1 — Handbook search")
print(DOCS["handbook"])
