# Lab 6 NLP Project
Three separate tasks based on the supplied Lab 6 manual.

## Setup (Windows PowerShell)
```powershell
cd Lab6_NLP_Project
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```
The first embedding run downloads `sentence-transformers/all-MiniLM-L6-v2` (CPU; no GPU or paid API).

## Run separately
```powershell
python task1_tokens.py
python task2_chunks.py
python task3_retrieval.py
```
Run only the self-introduction chatbot with `python task1_tokens.py --chat`.

Task 1 chatbot talks only about itself: its name, identity, purpose, abilities, working method and limitations. It does not answer general questions.

`task3_retrieval.py` compares 3 chunking strategies and TF-IDF/real sentence embeddings, prints Hit@3 and MRR@3 for development/test queries, and creates `retrieval_log.csv`.

All corpus/policy text is synthetic teaching data, not actual university rules. Scores are not probabilities or proof of correctness. Record actual outputs from your computer; do not invent timings or metrics. Do not upload `.venv`, model caches, credentials or private data to GitHub.
