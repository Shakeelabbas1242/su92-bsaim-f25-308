import json
with open("corpus.json",encoding="utf-8") as f: data=json.load(f)
print(f"Loaded {len(data)} synthetic documents.")
