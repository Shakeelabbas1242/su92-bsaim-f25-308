import json
with open("corpus.json",encoding="utf-8") as f: docs=json.load(f)
print("Scenario 5 — Equipment troubleshooting")
print(docs["printer"])
