from task2_chunks import DOCS
print("Scenario 2 — Customer support")
print(DOCS["returns"])
