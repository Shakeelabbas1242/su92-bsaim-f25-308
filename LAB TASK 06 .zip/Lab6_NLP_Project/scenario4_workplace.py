import json
with open("corpus.json",encoding="utf-8") as f: docs=json.load(f)
print("Scenario 4 — Workplace policy")
print(docs["workplace"])
