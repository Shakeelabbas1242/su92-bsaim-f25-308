"""Task 1: tokenizer comparison + chatbot that answers only about itself."""
import argparse, re
SAMPLES = ["AI, search!", "I can't log in.", "help@example.com", "CS4944", "", "یہ ایک مثال ہے"]

def compare_tokens():
    print("TASK 1 — TOKENIZATION")
    for text in SAMPLES:
        ws = text.split()
        words = re.findall(r"\b\w+\b", text, flags=re.UNICODE)
        print("\nOriginal:", repr(text))
        print("Whitespace:", ws, "count:", len(ws))
        print("Word-like:", words, "count:", len(words))
    print("\nOptional pretrained model subword tokens:")
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
        for text in SAMPLES[:2]:
            print(repr(text), "=>", model.tokenizer.tokenize(text))
    except Exception as exc:
        print("Model tokenizer unavailable:", exc)
    print("\nDifferences: whitespace splitting keeps punctuation attached; the regex removes punctuation")
    print("and splits contractions. Email addresses are split into pieces. This regex is not a full")
    print("multilingual tokenizer. Normalization may damage negation, punctuation or identifiers.")

def self_reply(question):
    q = question.strip().casefold()
    if not q: return "Please type a question about me."
    if any(x in q for x in ["name", "who are you", "yourself"]):
        return "My name is NLP Self-Info Bot. I am a simple Python chatbot created for Lab 6."
    if any(x in q for x in ["purpose", "why were you", "why are you"]):
        return "My purpose is to introduce myself and explain my own features."
    if any(x in q for x in ["can you", "ability", "abilities", "features"]):
        return "I can tell you my name, identity, purpose, features and how this demo works."
    if any(x in q for x in ["work", "how do you", "built", "made"]):
        return "I match your question with predefined self-information topics using Python conditions."
    if any(x in q for x in ["limit", "only", "cannot", "can't"]):
        return "I only answer questions about myself. I do not know private information about you."
    if any(x in q for x in ["creator", "created", "developer"]):
        return "I was created as a student practical demonstration using Python."
    return "I only answer questions about myself. Ask my name, purpose, abilities, working method or limitations."

def chatbot():
    print("\n=== NLP SELF-INFO CHATBOT ===\nAsk about me; type exit to stop.")
    while True:
        try: q = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!"); break
        if q.strip().casefold() in {"exit", "quit"}:
            print("Bot: Goodbye!"); break
        print("Bot:", self_reply(q))

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--chat", action="store_true")
    args=parser.parse_args()
    if not args.chat: compare_tokens()
    chatbot()
