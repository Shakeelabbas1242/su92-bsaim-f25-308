"""Task 2: 40-word windows (overlap 0/10) and sentence-aware chunking."""
import re
DOCS = {
"handbook": """The university learning portal is used to submit coursework and view assessment instructions. Students should check the module page before uploading a final assignment. A submitted file should be readable and should use the file format requested by the instructor. Late submission is normally subject to a penalty. An exception may be considered when a student experiences a documented illness. The student must provide appropriate medical evidence and request an extension before the original deadline. Approval is not automatic, and the course coordinator reviews the request. Students should keep the submission receipt as proof that the file was uploaded successfully. If the portal is unavailable, the student should capture the error message and contact the help desk promptly. The help desk can record the incident, but it cannot approve an academic extension. Students remain responsible for checking the final submission status. A draft saved on a personal computer is not considered a submitted assignment. This is synthetic classroom data.""",
"it_support": """Students who cannot access an account should first check that the username is typed correctly. A forgotten password can be reset by selecting the recovery link on the sign-in page. The recovery message is sent to the registered email address, so students should also inspect the spam folder. Never share a password or a recovery code with another person. If the registered email account is no longer available, the student should contact IT support through the official support process. Support staff may verify account ownership before changing account access. Repeated unsuccessful attempts can temporarily lock an account. In that situation, wait for the lock period to end or contact the help desk. Do not send passwords, one-time codes or private credentials in an ordinary email. This synthetic guide is for classroom practice.""",
"returns": """For a damaged parcel, the customer should contact the support team within 48 hours of delivery. The report should include clear photographs of the damaged item and its outer packaging. The order number should be included so that the parcel can be identified. Keep the original packaging until support confirms whether it is needed for inspection. A customer should not discard the item before receiving instructions. The 48-hour reporting window applies to the example region named PK in this teaching dataset. A different region may have a different reporting window, so region information must be checked. A change-of-mind return is separate and applies only to unused items returned within 14 days. This is synthetic customer-support text."""
}
def word_spans(text):
    return [(m.start(),m.end()) for m in re.finditer(r"\S+",text)]
def windows(text,size=40,overlap=10,offset=0):
    if size<=0 or not 0<=overlap<size: raise ValueError("Require size > 0 and 0 <= overlap < size")
    spans=word_spans(text); out=[]; step=size-overlap
    for i in range(0,len(spans),step):
        j=min(i+size,len(spans)); out.append((offset+spans[i][0],offset+spans[j-1][1]))
        if j==len(spans): break
    return out
def sentence_chunks(text,size=40):
    if size<=0: raise ValueError("size must be positive")
    cuts=[0]+[m.end() for m in re.finditer(r"[.!?]\s+",text)]+[len(text)]
    out=[]; pending=None; count=0
    for a,b in zip(cuts,cuts[1:]):
        seg=text[a:b]; n=len(seg.split())
        if not n: continue
        if n>size:
            if pending: out.append(pending)
            out.extend(windows(seg,size,0,a)); pending=None; count=0
        elif pending and count+n<=size:
            pending=(pending[0],b); count+=n
        else:
            if pending: out.append(pending)
            pending=(a,b); count=n
    if pending: out.append(pending)
    return out
def make_chunks(docs,strategy):
    result=[]
    for doc_id,text in docs.items():
        spans=sentence_chunks(text,40) if strategy=="sentence" else windows(text,40,int(strategy))
        for i,(a,b) in enumerate(spans):
            result.append({"id":f"{doc_id}:{i}","doc":doc_id,"start":a,"end":b,"text":text[a:b]})
    return result
if __name__=="__main__":
    print("TASK 2 — CHUNKING")
    original=sum(len(t.split()) for t in DOCS.values())
    for label,strategy in [("window overlap 0","0"),("window overlap 10","10"),("sentence aware","sentence")]:
        chunks=make_chunks(DOCS,strategy)
        emitted=sum(len(c["text"].split()) for c in chunks)
        print(f"\n{label}: {len(chunks)} chunks; estimated repeated words={emitted-original}")
        for c in chunks[:3]:
            assert c["text"]==DOCS[c["doc"]][c["start"]:c["end"]]
            print(c["id"],(c["start"],c["end"]),repr(c["text"][:100]))
    assert windows("")==[] and windows("short text")==[(0,10)]
    try: windows("a b",2,2)
    except ValueError: print("Invalid overlap test passed.")
    long=" ".join(["word"]*95)+"."
    assert all(len(long[a:b].split())<=40 for a,b in sentence_chunks(long))
    print("Long-sentence fallback test passed.")
    print("Limitation: simple punctuation splitting may split incorrectly around abbreviations (e.g. Dr.).")
