print("Scenario 3 — API documentation")
print("Renew an expired API token with POST /v2/token/refresh. Preserve endpoint case exactly.")
