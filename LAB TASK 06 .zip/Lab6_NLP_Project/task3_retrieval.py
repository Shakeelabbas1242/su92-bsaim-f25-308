"""Task 3: five-document retrieval evaluation; 3 splitters x TF-IDF/embeddings."""
import csv,json,time
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from task2_chunks import make_chunks
with open("corpus.json",encoding="utf-8") as f: DOCS=json.load(f)
QUESTIONS=[
{"query":"What evidence is needed for an illness extension?","doc":"handbook","evidence":"provide appropriate medical evidence and request an extension before the original deadline.","split":"dev"},
{"query":"Where should I upload my coursework?","doc":"handbook","evidence":"The university learning portal is used to submit coursework","split":"dev"},
{"query":"Can contractors work remotely?","doc":"workplace","evidence":"Contractors may work remotely only when the signed contract explicitly permits remote work.","split":"dev"},
{"query":"What should I do if the portal is unavailable?","doc":"handbook","evidence":"capture the error message and contact the help desk promptly.","split":"dev"},
{"query":"How can I regain access after forgetting my password?","doc":"it_support","evidence":"A forgotten password can be reset by selecting the recovery link on the sign-in page.","split":"test"},
{"query":"How soon must a damaged parcel be reported?","doc":"returns","evidence":"contact the support team within 48 hours of delivery.","split":"test"},
{"query":"What photos should I attach to a damage report?","doc":"returns","evidence":"clear photographs of the damaged item and its outer packaging.","split":"test"},
{"query":"What should I do when my printer produces blank pages?","doc":"printer","evidence":"run the printer cleaning utility and print a test page.","split":"test"},
{"query":"What are tomorrow's flight ticket prices?","doc":None,"evidence":None,"split":"test"},
{"query":"Who won yesterday's football match?","doc":None,"evidence":None,"split":"test"}]
def evaluate(scores,chunks,items):
    hits=[]; rr=[]
    for row,q in zip(scores,items):
        if q["doc"] is None: continue
        top=np.argsort(-row,kind="stable")[:3]
        ranks=[r for r,i in enumerate(top,1) if chunks[i]["doc"]==q["doc"] and q["evidence"] in chunks[i]["text"]]
        hits.append(bool(ranks)); rr.append(1/ranks[0] if ranks else 0)
    return (float(np.mean(hits)),float(np.mean(rr))) if hits else (None,None)
def main():
    for q in QUESTIONS:
        if q["doc"] is not None: assert q["evidence"] in DOCS[q["doc"]],q["query"]
    print("TASK 3 — DOCUMENT RETRIEVAL")
    model=None; t=time.perf_counter()
    try:
        from sentence_transformers import SentenceTransformer
        model=SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2",device="cpu")
        print(f"Model load seconds: {time.perf_counter()-t:.3f}")
    except Exception as e: print("Embedding model unavailable:",e,"; TF-IDF will still run.")
    query_texts=[q["query"] for q in QUESTIONS]; logs=[]
    for strategy in ["0","10","sentence"]:
        chunks=make_chunks(DOCS,strategy); texts=[c["text"] for c in chunks]
        for method in ["tfidf","embedding"]:
            if method=="embedding" and model is None: continue
            t=time.perf_counter()
            if method=="tfidf":
                vectorizer=TfidfVectorizer(); C=vectorizer.fit_transform(texts); Q=vectorizer.transform(query_texts)
                enc_time=time.perf_counter()-t; st=time.perf_counter(); scores=(Q@C.T).toarray()
            else:
                lens=[len(model.tokenizer(x,truncation=False)["input_ids"]) for x in texts+query_texts]
                if max(lens)>model.max_seq_length: raise ValueError("Encoder token limit exceeded.")
                C=model.encode(texts,normalize_embeddings=True,show_progress_bar=False)
                Q=model.encode(query_texts,normalize_embeddings=True,show_progress_bar=False)
                enc_time=time.perf_counter()-t; st=time.perf_counter(); scores=Q@C.T
            search_time=time.perf_counter()-st
            for split in ["dev","test"]:
                ix=[i for i,q in enumerate(QUESTIONS) if q["split"]==split and q["doc"] is not None]
                hit,mrr=evaluate(scores[ix],chunks,[QUESTIONS[i] for i in ix])
                print(f"{strategy:8} {method:9} {split}: Hit@3={hit:.3f} MRR@3={mrr:.3f} chunks={len(chunks)} encode={enc_time:.4f}s search={search_time:.4f}s")
            for row,q in zip(scores,QUESTIONS):
                for rank,i in enumerate(np.argsort(-row,kind="stable")[:3],1):
                    c=chunks[i]; logs.append({"strategy":strategy,"method":method,"query":q["query"],"split":q["split"],"answerable":q["doc"] is not None,"rank":rank,"score":float(row[i]),"chunk_id":c["id"],"doc":c["doc"],"start":c["start"],"end":c["end"],"text":c["text"]})
    if logs:
        with open("retrieval_log.csv","w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=list(logs[0])); w.writeheader(); w.writerows(logs)
        print("Saved retrieval_log.csv")
    print("Unanswerable queries are logged separately. A top-ranked passage is only a candidate,")
    print("not verified truth. Inspect source evidence and request confirmation before presenting an answer.")
    print("Discuss failures: split exceptions, paraphrase misses, unrelated top results, and sentence-split errors.")
if __name__=="__main__": main()
